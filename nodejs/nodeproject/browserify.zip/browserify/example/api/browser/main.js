var foo = require('./foo');
console.log(foo(5));
